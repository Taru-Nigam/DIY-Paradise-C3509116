<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Viewport meta tag -->
    <title><?php get_page_title(); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/reset.css"> <!-- Link to the CSS reset file -->
    <link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/style.css"> <!-- Use the theme URL for the stylesheet -->
    <meta name="description" content="DIY Paradise is a one stop shop for all hardware and home improvement products available at your fingertips with speedy delivery all throughout Australia."> <!-- SEO description -->
</head>
<body>
    <div class="background-main">
        <div class="wrapper clearfix">
            <!-- Page content -->
            <article>
                <section>
                    <!-- Title and content -->
                    <?php get_page_content(); ?> <!-- Display the page content, which should now include header and navigation -->
                </section>
            </article>
        </div>
    </div>
</body>
</html>