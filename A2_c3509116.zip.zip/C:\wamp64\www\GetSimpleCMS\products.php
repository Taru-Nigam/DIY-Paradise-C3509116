<?php
header('Content-Type: application/xml; charset=utf-8');

// Set product details
$productName = "(PRODUCT NAME)";
$description = "(INSERT DESCRIPTION)";
$currency = "(INSERT CURRENCY)";
$cost = "(COST OF ITEM)";
$tags = "(Insert Tags)";
$reviewScore = "Enter Score 0-5";
$reviewText = "(Enter Review Here)";
$image = "(Insert Image Here)";
$url = "https://example.com/(Productnamehere)";
$brand = "(Brand Here)";
$dimensions = [
    ["name" => "(Insert Here)", "value" => "(Insert Here)"],
    ["name" => "(Insert Here)", "value" => "(Insert Here)"],
    ["name" => "(Insert Here)", "value" => "(Insert Here)"],
    ["name" => "(Insert Here)", "value" => "(Insert Here)"],
];
$warranty = "(Warrenty Here)";

// Start XML output
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<!DOCTYPE product [
    <!ELEMENT product (name, description, pricing, search_tag, reviews, picture, url, brand, dimensions, warrenty)>
    <!ELEMENT name (#PCDATA)>
    <!ELEMENT description (#PCDATA)>
    <!ELEMENT pricing (#PCDATA)>
    <!ATTLIST pricing currency CDATA #REQUIRED>
    <!ELEMENT search_tag (tag*)>
    <!ELEMENT reviews (review*)>
    <!ELEMENT picture (#PCDATA)>
    <!ELEMENT url (#PCDATA)>
    <!ELEMENT dimensions (dimension+)>
    <!ELEMENT dimension EMPTY>
    <!ATTLIST dimension name CDATA #REQUIRED>
    <!ATTLIST dimension value CDATA #REQUIRED>
    <!ELEMENT warrenty (#PCDATA)>
    <!ELEMENT brand (#PCDATA)>
    <!ELEMENT review (#PCDATA)>
    <!ELEMENT tag (#PCDATA)>
    <!ATTLIST review score CDATA #REQUIRED>
    <!ENTITY company SYSTEM "DIY Paradise">
]>';

echo '<product>';
echo '<name>' . htmlspecialchars($productName) . '</name>';
echo '<description>' . htmlspecialchars($description) . '</description>';
echo '<pricing currency="' . htmlspecialchars($currency) . '">' . htmlspecialchars($cost) . '</pricing>';
echo '<search_tag>';
echo '<tag>' . htmlspecialchars($tags) . '</tag>';
echo '</search_tag>';
echo '<reviews>';
echo '<review score="' . htmlspecialchars($reviewScore) . '">' . htmlspecialchars($reviewText) . '</review>';
echo '</reviews>';
echo '<picture>' . htmlspecialchars($image) . '</picture>';
echo '<url>' . htmlspecialchars($url) . '</url>';
echo '<brand>' . htmlspecialchars($brand) . '</brand>';
echo '<dimensions>';
foreach ($dimensions as $dimension) {
    echo '<dimension name="' . htmlspecialchars($dimension['name']) . '" value="' . htmlspecialchars($dimension['value']) . '" />';
}
echo '</dimensions>';
echo '<warrenty>' . htmlspecialchars($warranty) . '</warrenty>';
echo '</product>';
?>