<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Second Hand Product Submission</title>
    <link rel="stylesheet" type="text/css" href="<?php get_theme_url(); ?>/style.css">
    <style>
        .required { color: red; }
        .error { color: red; display: none; }
    </style>
    <script>
        function validateForm() {
            const reviews = document.querySelectorAll('.review');
            let valid = true;
            let errorMessage = '';

            reviews.forEach((review) => {
                if (!/^\d(\.\d)? out of 5 stars$/.test(review.value)) {
                    valid = false;
                    errorMessage += 'Each review must contain the phrase "x out of 5 stars", where x is a number from 0 to 5.\n';
                }
            });

            if (!valid) {
                alert(errorMessage);
            }

            return valid;
        }

        function toggleNewCategoryInput() {
            const categorySelect = document.getElementById('category');
            const newCategoryContainer = document.getElementById('newCategoryContainer');
            newCategoryContainer.style.display = categorySelect.value === 'new' ? 'block' : 'none';
        }

        function updatePriceCategory() {
            const priceInput = document.getElementById('price');
            const priceDisplay = document.getElementById('priceDisplay');
            const categoryDisplay = document.getElementById('categoryDisplay');
            const price = parseFloat(priceInput.value) || 0;

            priceDisplay.value = price.toFixed(2);

            if (price < 0) {
                priceInput.value = 0;
                return;
            }

            let category = '';
            if (price == 0) {
                category = 'Free';
            } else if (price < 25) {
                category = 'Cheap';
            } else if (price >= 25 && price <= 100) {
                category = 'Affordable';
            } else if (price > 100) {
                category = 'Expensive';
            }

            categoryDisplay.value = category;
        }

        function addReview() {
            const reviewContainer = document.getElementById('reviewContainer');
            const newReview = document.createElement('input');
            newReview.type = 'text';
            newReview.className = 'review';
            newReview.placeholder = 'Enter your review (e.g., 4.5 out of 5 stars)';
            reviewContainer.appendChild(newReview);
        }

        function removeReview(button) {
            const reviewContainer = document.getElementById('reviewContainer');
            reviewContainer.removeChild(button.parentElement);
        }
    </script>
</head>
<body>
    <div class="background-main">
        <div class="content">
            <h1>DIY PARADISE</h1>
            <nav>
                <ul>
                    <li><a href="http://localhost/getsimplecms/">Home</a></li>
                    <li><a href="http://localhost/getsimplecms/index.php?id=about-us">About Us</a></li>
                    <li class="dropdown"><a>All Products</a>
                        <ul class="dropdown-menu">
                            <li><a href="http://localhost/getsimplecms/index.php?id=powertools">Power Tools</a></li>
                            <li><a href="http://localhost/getsimplecms/index.php?id=plumbingsupplies">Plumbing Supplies</a></li>
                            <li><a href="http://localhost/getsimplecms/index.php?id=submit">Submit A Review</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="right">
                    <li><a href="http://localhost/getsimplecms/index.php?id=contact">Contact</a></li>
                    <li><a href="http://localhost/getsimplecms/index.php?id=terms-and-conditions">Terms And Conditions</a></li>
                    <li><a href="http://localhost/getsimplecms/index.php?id=privacy-policy">Privacy Policy</a></li>
                </ul>
            </nav>

            <h1>Submit Your Second Hand Household Hardware Product</h1>
            <div class="contact-form">   
            <form action="submit.php" method="POST" onsubmit="return validateForm()">
                <h2>Submitter Information</h2>
                <label for="firstName">First Name <span class="required">*</span></label>
                <input type="text" id="firstName" name="firstName" required><br><br>

                <label for="lastName">Last Name <span class="required">*</span></label>
                <input type="text" id="lastName" name="lastName" required><br><br>

                <label for="email">Email Address <span class="required">*</span></label>
                <input type="email" id="email" name="email" required><br><br>

                <label>Have you submitted a product before? <span class="required">*</span></label>
                <input type="radio" id="yes" name="submittedBefore" value="yes" checked>
                <label for="yes">Yes</label>
                <input type="radio" id="no" name="submittedBefore" value="no">
                <label for="no">No</label><br><br>

                <h2>Product Information</h2>
                <label for="productName">Product Name <span class="required">*</span></label>
                <input type="text" id="productName" name="productName" required><br><br>

                <label for="category">Category <span class="required">*</span></label>
                <select id="category" name="category" required onchange="toggleNewCategoryInput()">
                    <option value="">Select a category</option>
                    <option value="powertools">Power Tools</option>
                    <option value="plumbingsupplies">Plumbing Supplies</option>
                    <option value="new">Create a new category</option>
                </select><br><br>

                <div id="newCategoryContainer" style="display: none;">
                    <label for="newCategory">New Category Name <span class="required">*</span></label>
                    <input type="text" id="newCategory" name="newCategory" placeholder="Enter new category name"><br><br>
                </div>

                <label for="price">Price <span class="required">*</span></label>
                <input type="number" id="price" name="price" min="0" step="0.01" required oninput="updatePriceCategory()"><br><br>

                <label for="priceDisplay">Price Display</label>
                <input type="text" id="priceDisplay" name="priceDisplay" readonly><br><br>

                <label for="categoryDisplay">Price Category</label>
                <input type="text" id="categoryDisplay" name="categoryDisplay" readonly><br><br>

                <label>Terms and Conditions <span class="required">*</span></label>
                <input type="checkbox" id="terms" name="terms" required>
                <label for="terms">I have read the terms and conditions</label><br><br>

                <h2>Reviews</h2>
                <div id="reviewContainer">
                    <input type="text" class="review" name="review[]" placeholder="Enter your review (e.g., 4.5 out of 5 stars)">
                </div>
                <button type="button" onclick="addReview()">Add Review</button><br><br>

                <button type="submit">Submit</button>
                <button type="reset">Clear</button>
            </form>
            </div>
        </div>
    </div>

    <footer>
        <p>© 2024 DIY PARADISE. All rights reserved. <a href="mailto:diyparadise@example.com">diyparadise@example.com</a></p>
    </footer>
</body>
</html>