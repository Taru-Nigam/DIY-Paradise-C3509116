<?php
// Start output buffering to handle redirects without errors
ob_start();

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize form data
    $firstName = htmlspecialchars(trim($_POST['firstName']));
    $lastName = htmlspecialchars(trim($_POST['lastName']));
    $email = htmlspecialchars(trim($_POST['email']));
    $submittedBefore = htmlspecialchars(trim($_POST['submittedBefore']));
    $productName = htmlspecialchars(trim($_POST['productName']));
    $category = htmlspecialchars(trim($_POST['category']));
    $newCategory = isset($_POST['newCategory']) ? htmlspecialchars(trim($_POST['newCategory'])) : ''; // New category input
    $price = htmlspecialchars(trim($_POST['price']));
    $priceDisplay = htmlspecialchars(trim($_POST['priceDisplay']));
    $categoryDisplay = htmlspecialchars(trim($_POST['categoryDisplay']));
    $terms = isset($_POST['terms']) ? true : false; // Checkbox is either checked or not
    $reviews = []; // Initialize an array to hold reviews

    // Collect reviews if they were submitted
    if (isset($_POST['review'])) {
        foreach ($_POST['review'] as $review) {
            $reviews[] = htmlspecialchars(trim($review));
        }
    }

    // Validate required fields
    if (empty($firstName) || empty($lastName) || empty($email) || empty($productName) || 
        (empty($category) && empty($newCategory)) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Redirect back to the form with an error message
        header("Location: submit form.php?error=" . urlencode("Please fill in all required fields with valid information."));
        exit;
    }

    // Check if terms are accepted
    if (!$terms) {
        // Redirect back to the form with an error message
        header("Location: submit form.php?error=" . urlencode("You must accept the terms and conditions."));
        exit;
    }

    // Determine the category name for the XML file
    $categoryName = !empty($newCategory) ? $newCategory : $category; // Use new category if provided
    $templatePath = 'data/pages/products/product_template.xml';
    $newCategoryPath = 'data/pages/products/' . $categoryName . '.xml';

    // Check if the category XML file exists or create it
    if (!file_exists($newCategoryPath)) {
        // Copy the template file to create a new category file
        if (!copy($templatePath, $newCategoryPath)) {
            // Redirect back to the form with an error message
            header("Location: submit form.php?error=" . urlencode("Failed to create new category file."));
            exit;
        }
    }

    // Load the XML file
    $xml = simplexml_load_file($newCategoryPath);
    if ($xml === false) {
        // Redirect back to the form with an error message
        header("Location: submit form.php?error=" . urlencode("Failed to load category file."));
        exit;
    }

    // Create a new product entry in the XML
    $product = $xml->addChild('product');
    $product->addChild('name', $productName);
    $product->addChild('description', ''); // Placeholder for description
    $pricing = $product->addChild('pricing', $price);
    $pricing->addAttribute('currency', 'AUD');
    $searchTag = $product->addChild('search_tag');
    $searchTag->addChild('tag', ''); // Placeholder for tags
    $product->addChild('picture', ''); // Placeholder for image
    $product->addChild('url', 'https://example.com/' . urlencode($productName)); // Example URL
    $product->addChild('brand', ''); // Placeholder for brand

    // Add reviews if any
    $reviewsElement = $product->addChild('reviews');
    if (!empty($reviews)) {
        foreach ($reviews as $review) {
            $score = ''; // Extract score from review text if needed
            $reviewEntry = $reviewsElement->addChild('review', $review);
            $reviewEntry->addAttribute('score', $score); // Set score attribute if applicable
    }
}

    $dimensions = $product->addChild('dimensions');
        for ($i = 0; $i < 4; $i++) { // Assuming you want to add 4 dimensions
        $dimension = $dimensions->addChild('dimension');
        $dimension->addAttribute('name', 'Dimension ' . ($i + 1)); // Placeholder name
        $dimension->addAttribute('value', 'Value ' . ($i + 1)); // Placeholder value
}

// Add warranty
$product->addChild('warranty', ''); // Placeholder for warranty

    // Save the updated XML back to the file
    if ($xml->asXML($newCategoryPath) === false) {
        // Redirect back to the form with an error message
        header("Location: submit form.php?error=" . urlencode("Failed to save category file."));
        exit;
    }

    // Redirect to the category page showing the new product
    header("Location: products.php?category=" . urlencode($categoryName) . "#product-" . urlencode($productName));
    exit;

} else {
    // Invalid request
    header("Location: submit form.php?error=" . urlencode("Invalid request."));
    exit;
}

// Flush the output buffer
ob_end_flush();
?>