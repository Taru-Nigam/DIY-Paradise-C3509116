<?php 
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>DIY Paradise</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <!-- Background image and left side margin -->
  <div class="background-main">
    <div class="content">
      <!-- Level 1 Header -->
      <h1>DIY PARADISE</h1>
      <!-- Navigation Bar -->
      <nav>
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="about.html">About Us</a></li>
          <li class="dropdown">
          <a>All Products</a>
          <ul class="dropdown-menu">
            <li><a href="powertools.xml">Power Tools</a></li>
            <li><a href="plumbingsupplies.xml">Plumbing Supplies</a></li>
          </ul>
          </li>
        </ul>
        <ul class="right">
          <li><a href="contact.html">Contact</a></li>
          <li><a href="terms-and-conditions.html">Terms And Conditions</a></li>
          <li><a href="privacy-policy.html">Privacy Policy</a></li>
        </ul>
      </nav>
      <!-- Level 2 Header -->
      <h2>Welcome to DIY Paradise</h2>
      <!-- Welcoming paragraph -->
      <div class="box">
        <p>Welcome to DIY Paradise! Your one-stop shop for all your household hardware needs. We make it convenient and easy to buy everything you need for your home projects. Our extensive range of products covers all categories, from kitchen essentials to building supplies, plumbing tools, and gardening equipment. Whether you’re looking for a new stand mixer for your kitchen, a pipe wrench for your plumbing tasks, or a power drill for your latest DIY project, we’ve got you covered. Explore our wide selection and find exactly what you need to make your home improvement dreams a reality.</p>
      </div>
      <h2>Featured Products</h2>
      <!-- Featured Products -->
      <div class="product-container"> 
        <div class="product">
          <ul>
            <li>
              <img src="uploads/metal-pipe-plumbing-d7QRlz5-600.png" alt="Quantum Flux Pipe">
              <strong><span class="highlight">Quantum Flux Pipe</span></strong> 
              <br> 
              <p>A faucet that defies gravity, allowing water to flow upwards. Perfect for those who want to challenge the laws of physics in their bathroom.</p>
            </li>
          </ul>
        </div>
      </div>
      <div class="product-container"> 
        <div class="product">
          <ul>
            <li>
              <img src="uploads/Futuristic-toilets-10-jpg.png" alt="Time-Traveling Toilet">
              <strong><span class="highlight">Time-Traveling Toilet</span></strong> 
              <br> 
              <p>A toilet that allows you to travel back in time to before you needed to use it. Never worry about bathroom breaks again!</p>
            </li>
          </ul>
        </div>
      </div>
      <div class="product-container"> 
        <div class="product">
          <ul>
            <li>
              <img src="uploads/blogimage1320233172smart-tech-savvy.png" alt="Self-Cleaning Sink">
              <strong><span class="highlight">Self-Cleaning Sink</span></strong> 
              <br> 
              <p>A sink that cleans itself and any dishes placed in it using nanotechnology. Say goodbye to dishwashing forever!</p>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Hyperlink to external website -->
  <footer>
    <p>For more information on our products, please visit our <a href="products.html">products page</a> 
      <br>
      Or, visit the <a href="http://www.newcastle.edu.au">University of Newcastle</a> website for more information on Information Technology courses.</p>
    <!-- Copyright statement -->
    <p>&copy; 2024 DIY PARADISE. All rights reserved. <a href="mailto:diyparadise@example.com">diyparadise@example.com</a></p>
  </footer>
</body>
</html>
?>