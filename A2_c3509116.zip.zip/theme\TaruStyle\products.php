<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php get_page_clean_title(); ?></title>
    <link href="<?php get_theme_url(); ?>/style.css" rel="stylesheet">
    <script>
        // Store the name of the category and the current date/time in a cookie
        function setCategoryCookie(category) {
            const date = new Date();
            const expires = new Date(date.getTime() + (7 * 24 * 60 * 60 * 1000)); // 1 week
            document.cookie = "lastViewedCategory=" + category + "; expires=" + expires.toUTCString() + "; path=/";
        }
        
        // Check if there is a cookie and display the last viewed category
        function checkCategoryCookie() {
            const cookies = document.cookie.split(';');
            for (let cookie of cookies) {
                const [name, value] = cookie.split('=').map(c => c.trim());
                if (name === 'lastViewedCategory') {
                    alert("Welcome back! You last viewed: " + value + " on " + new Date().toLocaleString());
                }
            }
        }
        
        window.onload = function() {
            const category = "<?php echo htmlspecialchars($_GET['category']); ?>";
            setCategoryCookie(category);
            checkCategoryCookie();
        }
    </script>
</head>
<body>
    <div class="background-main">
        <!-- Page content -->
        <div class="content">
        <!-- Level 1 Header -->
        <h1>DIY PARADISE</h1>
        <nav>
	    <ul>
		    <li><a href="http://localhost/getsimplecms/">Home</a></li>
		    <li><a href="http://localhost/getsimplecms/index.php?id=about-us">About Us</a></li>
		    <li class="dropdown"><a>All Products</a>
	        <ul class="dropdown-menu">
                <li><a href="http://localhost/getsimplecms/index.php?id=powertools">Power Tools</a></li>
                <li><a href="http://localhost/getsimplecms/index.php?id=plumbingsupplies">Plumbing Supplies</a></li>
                <li><a href="http://localhost/getsimplecms/index.php?id=submit">Submit A Review</a></li>
	        </ul>
    	    </li>
	    </ul>

		    <ul class="right">
			    <li><a href="http://localhost/getsimplecms/index.php?id=contact">Contact</a></li>
			    <li><a href="http://localhost/getsimplecms/index.php?id=terms-and-conditions">Terms And Conditions</a></li>
			    <li><a href="http://localhost/getsimplecms/index.php?id=privacy-policy">Privacy Policy</a></li>
		    </ul>
	    </nav>
        <?php
            if (isset($_GET['id'])) {
                $category = $_GET['id']; // Get the category from the URL
            } else {
                die('Error: No category specified in the URL.'); // Handle the case where category is not set
            }

            // Construct the XML file name based on the category
            $xmlFile = 'data/pages/products/' . $category . '.xml';

            // Load the XML file
            if (file_exists($xmlFile)) {
                $xml = simplexml_load_file($xmlFile);
            } else {
                die('Error: XML file not found for category ' . htmlspecialchars($category) . '.');
            }

        // Sort products by name
        $products = [];
        foreach ($xml->product as $product) {
            $products[] = $product;
        }
        usort($products, function($a, $b) {
            return strcmp((string)$a->name, (string)$b->name);
        });

        ?>

        <div class="product-category">
        <h1>Products</h1>
        <?php if (count($products) > 0): ?>
            <div class="product-container">
                <?php foreach ($products as $product): ?>
                    <div class="product">
                        <h2><?php echo $product->name; ?></h2>
                        <p><strong>Description:</strong> <?php echo $product->description; ?></p>
                        <p><strong>Price:</strong> <?php echo $product->pricing; ?> (Currency: <?php echo $product->pricing['currency']; ?>)</p>
                        <p><strong>Brand:</strong> <?php echo $product->brand; ?></p>
                        <p><strong>Warranty:</strong> <?php echo $product->warrenty; ?></p>
                        <p><strong>URL:</strong> <a href="<?php echo $product->url; ?>"><?php echo $product->url; ?></a></p>
                        <p><img src="<?php echo $product->picture; ?>" alt="<?php echo $product->name; ?>" /></p>

                        <h3>Search Tags</h3>
                            <?php foreach ($product->search_tag->tag as $tag): ?>
                                <p><?php echo $tag; ?></p>
                            <?php endforeach; ?>

                        <h3>Reviews</h3>
                            <?php foreach ($product->reviews->review as $review): ?>
                                    <p>
                                    <strong>Score:</strong> <?php echo $review['score']; ?> - 
                                    <?php echo $review; ?>
                                    </p>
                            <?php endforeach; ?>
                    </div>
                    </li>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p>No products found in this category.</p>
        <?php endif; ?>
        </div>
    </div>
  <!-- CopyRight Statement -->
  <footer>
    <p>&copy; 2024 DIY PARADISE. All rights reserved. <a href="mailto:diyparadise@example.com">diyparadise@example.com</a></p>
  </footer>

</body>
</html>